# Divergence Detector

### Prerequisites

First, install [npm](https://www.npmjs.com) (we assume you have pre-installed [node.js](https://nodejs.org)).

### Setup

Install dependencies

    npm install

Start the app

    npm run now